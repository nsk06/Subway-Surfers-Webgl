// Play the audio file using HTMLAudioElement

var audio = new Audio("./subway_surfers.mp3");
audio.play();
